
package Formulario;

import javax.swing.table.DefaultTableModel;
import java.math.BigDecimal;
import java.math.RoundingMode;
import Controlador.DAOFactura;
import javax.swing.JOptionPane;


public class Facturas extends javax.swing.JInternalFrame {
    
    private DefaultTableModel modeloFactura;
    private static final BigDecimal IGV_PORC = new BigDecimal("0.18");
    private int idVentaActual; // ESTE VIENE DE VENTAS
    private DAOFactura daoFactura = new DAOFactura();

    
    public Facturas(int idVenta) {
    initComponents();
    this.idVentaActual = idVenta;

    modeloFactura = (DefaultTableModel) tablaFactura.getModel();
    txtSubtotal.setEditable(false);
    txtIgv.setEditable(false);
    txtTotal.setEditable(false);

    // opcional pro: recalcular cuando editen la tabla
    tablaFactura.getModel().addTableModelListener(e -> recalcularTotales());

    recalcularTotales();
}
    
    
    public void cargarItemsEnTabla(Object[][] items) {
        modeloFactura.setRowCount(0);
        for (Object[] row : items) {
            modeloFactura.addRow(row);
        }
        recalcularTotales();
    }
    
    private void recalcularTotales() {
    BigDecimal subtotal = BigDecimal.ZERO;

    for (int i = 0; i < modeloFactura.getRowCount(); i++) {
        try {
            Object pObj = modeloFactura.getValueAt(i, 2); // Precio
            Object cObj = modeloFactura.getValueAt(i, 3); // Cantidad

            if (pObj == null || cObj == null) continue;

            BigDecimal precio = new BigDecimal(pObj.toString().trim());
            int cant = Integer.parseInt(cObj.toString().trim());

            if (cant < 0) cant = 0;

            subtotal = subtotal.add(precio.multiply(BigDecimal.valueOf(cant)));
        } catch (Exception ex) {
            // Si hay un dato malo en una fila, la ignoramos para no romper todo
        }
    }

    BigDecimal igv = subtotal.multiply(IGV_PORC).setScale(2, RoundingMode.HALF_UP);
    BigDecimal total = subtotal.add(igv).setScale(2, RoundingMode.HALF_UP);

    txtSubtotal.setText(subtotal.setScale(2, RoundingMode.HALF_UP).toString());
    txtIgv.setText(igv.toString());
    txtTotal.setText(total.toString());
}

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel16 = new javax.swing.JLabel();
        btnRegresar = new javax.swing.JButton();
        jLabel17 = new javax.swing.JLabel();
        txtDniCliente = new javax.swing.JTextField();
        txtTelefonoCliente = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        txtNombreCliente = new javax.swing.JTextField();
        txtIgv = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        txtTotal = new javax.swing.JTextField();
        btnImprimir = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();
        btnEliminar = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        btnGuardarFactura = new javax.swing.JButton();
        txtSubtotal = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        tablaFactura = new javax.swing.JTable();

        setClosable(true);

        jLabel16.setText("Nombre:");

        btnRegresar.setText("Regresar");
        btnRegresar.addActionListener(this::btnRegresarActionPerformed);

        jLabel17.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        jLabel17.setText("ZonaGamer");

        jLabel18.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel18.setText("Factura de Venta");

        jLabel14.setText("Telefono:");

        jLabel19.setText("DNI:");

        jLabel15.setText("Total:");

        btnImprimir.setText("Imprimir");
        btnImprimir.addActionListener(this::btnImprimirActionPerformed);

        jLabel20.setText("Subtotal:");

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(this::btnEliminarActionPerformed);

        jLabel21.setText("Igv:");

        btnGuardarFactura.setText("Guardar");
        btnGuardarFactura.addActionListener(this::btnGuardarFacturaActionPerformed);

        txtSubtotal.addActionListener(this::txtSubtotalActionPerformed);

        tablaFactura.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "Categoria", "Precio", "Cantidad"
            }
        ));
        jScrollPane3.setViewportView(tablaFactura);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(74, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnImprimir)
                    .addComponent(jLabel18)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel17))
                .addGap(44, 44, 44))
            .addGroup(layout.createSequentialGroup()
                .addGap(126, 126, 126)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel21)
                            .addGap(34, 34, 34)
                            .addComponent(txtIgv, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel15)
                                .addComponent(jLabel20))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(27, 27, 27)
                                    .addComponent(txtSubtotal, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addGap(18, 18, 18)
                                    .addComponent(txtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnGuardarFactura)
                        .addGap(28, 28, 28)
                        .addComponent(btnEliminar)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(1, 1, 1)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(btnRegresar)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(34, 34, 34)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel14)
                                    .addGap(30, 30, 30)
                                    .addComponent(txtTelefonoCliente))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel16)
                                    .addGap(30, 30, 30)
                                    .addComponent(txtNombreCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel19)
                                    .addGap(30, 30, 30)
                                    .addComponent(txtDniCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addContainerGap(237, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel17)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel18)
                .addGap(248, 248, 248)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(46, 46, 46)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel20)
                    .addComponent(txtSubtotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(txtIgv, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnImprimir))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(txtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 51, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnEliminar)
                    .addComponent(btnGuardarFactura, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(18, 18, 18))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(41, 41, 41)
                    .addComponent(btnRegresar)
                    .addGap(58, 58, 58)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtNombreCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel16))
                    .addGap(18, 18, 18)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtDniCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel19))
                    .addGap(27, 27, 27)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtTelefonoCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel14))
                    .addContainerGap(557, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresarActionPerformed
        // TODO add your handling code here:
        this.dispose();
       
    }//GEN-LAST:event_btnRegresarActionPerformed

    private void btnImprimirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImprimirActionPerformed
        // TODO add your handling code here:
        try {
        String headerTxt = "ZonaGamer - Factura de Venta";
        String footerTxt = "Total: " + txtTotal.getText();

        java.text.MessageFormat header = new java.text.MessageFormat(headerTxt);
        java.text.MessageFormat footer = new java.text.MessageFormat(footerTxt);

        boolean ok = tablaFactura.print(javax.swing.JTable.PrintMode.FIT_WIDTH, header, footer);

        if (ok) {
            javax.swing.JOptionPane.showMessageDialog(this, "Enviado a impresión.");
        }
    } catch (Exception e) {
        javax.swing.JOptionPane.showMessageDialog(this, "Error al imprimir: " + e.getMessage());
    }
        
    }//GEN-LAST:event_btnImprimirActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        // TODO add your handling code here:
        int fila = tablaFactura.getSelectedRow();
        if (fila == -1) {
            javax.swing.JOptionPane.showMessageDialog(this, "Selecciona una fila para eliminar.");
            return;
        }

        modeloFactura.removeRow(fila);
        recalcularTotales();
       
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnGuardarFacturaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarFacturaActionPerformed
        // TODO add your handling code here:
        
        int r = JOptionPane.showConfirmDialog(
        this,
        "¿Deseas emitir la factura de la venta #" + idVentaActual + "?\nTotal: " + txtTotal.getText(),
        "Confirmar factura",
        JOptionPane.YES_NO_OPTION
        );

        if (r != JOptionPane.YES_OPTION) return;

        try {
        if (idVentaActual <= 0) {
            JOptionPane.showMessageDialog(this, "No hay una venta válida asociada (id_venta).");
            return;
        }

            if (modeloFactura.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "No hay productos en la factura.");
                return;
            }

            recalcularTotales();

            double iva = Double.parseDouble(txtIgv.getText());
            double total = Double.parseDouble(txtTotal.getText());

            daoFactura.insertarFactura(idVentaActual, iva, total);

            JOptionPane.showMessageDialog(this, "Factura emitida correctamente.");
            limpiarFactura();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al emitir factura: " + e.getMessage());
        }
    }//GEN-LAST:event_btnGuardarFacturaActionPerformed

    private void txtSubtotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSubtotalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSubtotalActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardarFactura;
    private javax.swing.JButton btnImprimir;
    private javax.swing.JButton btnRegresar;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable tablaFactura;
    private javax.swing.JTextField txtDniCliente;
    private javax.swing.JTextField txtIgv;
    private javax.swing.JTextField txtNombreCliente;
    private javax.swing.JTextField txtSubtotal;
    private javax.swing.JTextField txtTelefonoCliente;
    private javax.swing.JTextField txtTotal;
    // End of variables declaration//GEN-END:variables

private void limpiarFactura() {
    txtNombreCliente.setText("");
    txtDniCliente.setText("");
    txtTelefonoCliente.setText("");

    DefaultTableModel model = (DefaultTableModel) tablaFactura.getModel();
    model.setRowCount(0);

    txtSubtotal.setText("0.00");
    txtIgv.setText("0.00");
    txtTotal.setText("0.00");
}


}
