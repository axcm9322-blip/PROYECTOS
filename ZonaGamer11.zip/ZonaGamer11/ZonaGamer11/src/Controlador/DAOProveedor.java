
package Controlador;

import Conex.coneccion;
import Entidades.Proveedores;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DAOProveedor {
   public void insertar(Proveedores p) throws SQLException {
        String sql = "INSERT INTO proveedores(nombre, contacto, telefono, email) "
                   + "VALUES(?,?,?,?)";
        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setString(1, p.getNombre());
            ps.setString(2, p.getContacto());
            ps.setString(3, p.getTelefono());
            ps.setString(4, p.getEmail());
            ps.executeUpdate();
        }
    }

    public void modificar(Proveedores p) throws SQLException {
        String sql = "UPDATE proveedores SET nombre=?, contacto=?, telefono=?, email=? "
                   + "WHERE id_proveedor=?";
        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setString(1, p.getNombre());
            ps.setString(2, p.getContacto());
            ps.setString(3, p.getTelefono());
            ps.setString(4, p.getEmail());
            ps.setInt(5, p.getIdProveedor());
            ps.executeUpdate();
        }
    }

    public void eliminar(int idProveedor) throws SQLException {
        String sql = "DELETE FROM proveedores WHERE id_proveedor=?";
        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setInt(1, idProveedor);
            ps.executeUpdate();
        }
    }

    public Proveedores obtenerPorId(int idProveedor) throws SQLException {
        String sql = "SELECT * FROM proveedores WHERE id_proveedor=?";
        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setInt(1, idProveedor);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapear(rs);
                }
            }
        }
        return null;
    }

    public List<Proveedores> listarTodos() throws SQLException {
        List<Proveedores> lista = new ArrayList<>();
        String sql = "SELECT * FROM proveedores";
        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapear(rs));
            }
        }
        return lista;
    }
    
    public List<Proveedores> buscar(String texto) throws SQLException {
    List<Proveedores> lista = new ArrayList<>();

    String sql = "SELECT * FROM proveedores "
               + "WHERE nombre LIKE ? OR contacto LIKE ? OR telefono LIKE ? OR email LIKE ?";

    try (Connection cn = coneccion.getConnection();
         PreparedStatement ps = cn.prepareStatement(sql)) {

        String q = "%" + texto + "%";
        ps.setString(1, q);
        ps.setString(2, q);
        ps.setString(3, q);
        ps.setString(4, q);

        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapear(rs));
            }
        }
    }
    return lista;
}


    private Proveedores mapear(ResultSet rs) throws SQLException {
        return new Proveedores(
            rs.getInt("id_proveedor"),
            rs.getString("nombre"),
            rs.getString("contacto"),
            rs.getString("telefono"),
            rs.getString("email")
        );
    }
    
}
