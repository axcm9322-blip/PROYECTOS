
package Controlador;

import Conex.coneccion;
import Entidades.Empleado;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DAOEmpleado {
     public Empleado login(String usuario, String clave, String tipo) throws SQLException {
        String sql = "SELECT * FROM empleados "
                   + "WHERE email=? AND clave=? AND tipo_empleado=?";
        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setString(1, usuario);
            ps.setString(2, clave);
            ps.setString(3, tipo);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapear(rs);
                }
            }
        }
        return null;
    }
     public void insertar(Empleado e) throws SQLException {
        String sql = "INSERT INTO empleados(nombre, apellido, email, telefono, puesto, "
                   + "tipo_empleado, clave, salario, fecha_contratacion) "
                   + "VALUES(?,?,?,?,?,?,?,?,?)";
        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setString(1, e.getNombre());
            ps.setString(2, e.getApellido());
            ps.setString(3, e.getEmail());
            ps.setString(4, e.getTelefono());
            ps.setString(5, e.getPuesto());
            ps.setString(6, e.getTipoEmpleado());
            ps.setString(7, e.getClave());
            ps.setDouble(8, e.getSalario());
            ps.setDate(9, new java.sql.Date(e.getFechaContratacion().getTime()));
            ps.executeUpdate();
        }
    }

    public void modificar(Empleado e) throws SQLException {
        String sql = "UPDATE empleados SET nombre=?, apellido=?, email=?, telefono=?, puesto=?, "
                   + "tipo_empleado=?, clave=?, salario=?, fecha_contratacion=? "
                   + "WHERE id_empleado=?";
        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setString(1, e.getNombre());
            ps.setString(2, e.getApellido());
            ps.setString(3, e.getEmail());
            ps.setString(4, e.getTelefono());
            ps.setString(5, e.getPuesto());
            ps.setString(6, e.getTipoEmpleado());
            ps.setString(7, e.getClave());
            ps.setDouble(8, e.getSalario());
            ps.setDate(9, new java.sql.Date(e.getFechaContratacion().getTime()));
            ps.setInt(10, e.getIdEmpleado());
            ps.executeUpdate();
        }
    }

    public void eliminar(int idEmpleado) throws SQLException {
        String sql = "DELETE FROM empleados WHERE id_empleado=?";
        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setInt(1, idEmpleado);
            ps.executeUpdate();
        }
    }

    public Empleado obtenerPorId(int idEmpleado) throws SQLException {
        String sql = "SELECT * FROM empleados WHERE id_empleado=?";
        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setInt(1, idEmpleado);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapear(rs);
                }
            }
        }
        return null;
    }

    public List<Empleado> listarTodos() throws SQLException {
        List<Empleado> lista = new ArrayList<>();
        String sql = "SELECT * FROM empleados";
        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapear(rs));
            }
        }
        return lista;
    }

    private Empleado mapear(ResultSet rs) throws SQLException {
        return new Empleado(
            rs.getInt("id_empleado"),
            rs.getString("nombre"),
            rs.getString("apellido"),
            rs.getString("email"),
            rs.getString("telefono"),
            rs.getString("puesto"),
            rs.getString("tipo_empleado"),
            rs.getString("clave"),
            rs.getDouble("salario"),
            rs.getDate("fecha_contratacion")
        );
    }
    
}
