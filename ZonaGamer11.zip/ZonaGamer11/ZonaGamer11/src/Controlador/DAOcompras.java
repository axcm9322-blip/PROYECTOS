
package Controlador;


import Conex.coneccion;
import Entidades.Compra;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DAOcompras {

     private static final String INSERT_SQL =
        "INSERT INTO compra (id_proveedor, fecha_pedido, fecha_entrega_estimada, estado, total) " +
        "VALUES (?, ?, ?, ?, ?)";

    private static final String UPDATE_SQL =
        "UPDATE compra SET id_proveedor=?, fecha_pedido=?, fecha_entrega_estimada=?, estado=?, total=? " +
        "WHERE id_pedido=?";



    public ArrayList<Compra> listar() throws SQLException {
        ArrayList<Compra> lista = new ArrayList<>();

        String sql = "SELECT id_pedido, id_proveedor, fecha_pedido, fecha_entrega_estimada, estado, total " +
                     "FROM compra";

        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

         while (rs.next()) {
    Compra p = new Compra();

    p.setIdPedido(rs.getInt("id_pedido"));
    p.setIdProveedor(rs.getInt("id_proveedor"));
    p.setFechaPedido(rs.getDate("fecha_pedido"));
    p.setFechaEntregaEstimada(rs.getDate("fecha_entrega_estimada"));
    p.setEstado(rs.getString("estado"));
    p.setTotal(rs.getDouble("total"));

    lista.add(p);
}

        }
        return lista;
    }

   
    public void insertar(Compra c) throws SQLException {

        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(INSERT_SQL)) {

            ps.setInt(1, c.getIdProveedor());

            ps.setDate(2, new java.sql.Date(c.getFechaPedido().getTime()));
            ps.setDate(3, new java.sql.Date(c.getFechaEntregaEstimada().getTime()));

            ps.setString(4, c.getEstado());
            ps.setDouble(5, c.getTotal());

            ps.executeUpdate();
        }
    }


    public void actualizar(Compra c) throws SQLException {

        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(UPDATE_SQL)) {

            ps.setInt(1, c.getIdProveedor());
            ps.setDate(2, new java.sql.Date(c.getFechaPedido().getTime()));
            ps.setDate(3, new java.sql.Date(c.getFechaEntregaEstimada().getTime()));
            ps.setString(4, c.getEstado());
            ps.setDouble(5, c.getTotal());
            ps.setInt(6, c.getIdPedido());

            ps.executeUpdate();
        }
    }


    public void eliminar(int idPedido) throws SQLException {

        String sql = "DELETE FROM compra WHERE id_pedido=?";

        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setInt(1, idPedido);
            ps.executeUpdate();
        }
    }


    public Compra obtenerPorId(int idPedido) throws SQLException {

        String sql = "SELECT * FROM compra WHERE id_pedido=?";

        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setInt(1, idPedido);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapear(rs);
                }
            }
        }
        return null;
    }

    private Compra mapear(ResultSet rs) throws SQLException {

        Compra c = new Compra();
        c.setIdPedido(rs.getInt("id_pedido"));
        c.setIdProveedor(rs.getInt("id_proveedor"));
        c.setFechaPedido(rs.getDate("fecha_pedido"));
        c.setFechaEntregaEstimada(rs.getDate("fecha_entrega_estimada"));
        c.setEstado(rs.getString("estado"));
        c.setTotal(rs.getDouble("total"));

        return c;
    }
    
    public List<Compra> listarTodos() throws SQLException {
        List<Compra> lista = new ArrayList<>();
        String sql = "SELECT * FROM compra";
        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapear(rs));
            }
        }
        return lista;
    }
    
    public ArrayList<Compra> buscarPorEstado(String estado) throws SQLException {

    ArrayList<Compra> lista = new ArrayList<>();

    String sql = "SELECT id_pedido, id_proveedor, fecha_pedido, " +
                 "fecha_entrega_estimada, estado, total " +
                 "FROM compra WHERE estado LIKE ?";

    try (Connection cn = coneccion.getConnection();
         PreparedStatement ps = cn.prepareStatement(sql)) {

        ps.setString(1, "%" + estado + "%");

        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Compra c = new Compra();
                c.setIdPedido(rs.getInt("id_pedido"));
                c.setIdProveedor(rs.getInt("id_proveedor"));
                c.setFechaPedido(rs.getDate("fecha_pedido"));
                c.setFechaEntregaEstimada(rs.getDate("fecha_entrega_estimada"));
                c.setEstado(rs.getString("estado"));
                c.setTotal(rs.getDouble("total"));

                lista.add(c);
            }
        }
    }
    return lista;
}

    
}
