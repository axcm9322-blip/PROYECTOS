
package Controlador;
import Conex.coneccion;
import Entidades.Clientes;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DAOCliente {
    public void insertar(Clientes c) throws SQLException {
        String sql = "INSERT INTO clientes(nombre, apellido, email, telefono, direccion, fecha_registro, status)"
                   + "VALUES(?,?,?,?,?,?,?,?)";
        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            
            ps.setString(1, c.getNombre());
            ps.setString(2, c.getApellido());
            ps.setString(3, c.getEmail());
            ps.setString(4, c.getTelefono());
            ps.setString(5, c.getDireccion());
            ps.setDate(6, (Date) c.getFechaRegistro());
            
            ps.executeUpdate();
        }
    }

    public void modificar(Clientes c) throws SQLException {
        String sql = "UPDATE clientes SET nombre=?, apellido=?, email=?, telefono=?, direccion=? "
                   + "WHERE id_cliente=?";
        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, c.getNombre());
            ps.setString(2, c.getApellido());
            ps.setString(3, c.getEmail());
            ps.setString(4, c.getTelefono());
            ps.setString(5, c.getDireccion());
            ps.setDate(6, (Date) c.getFechaRegistro());
            ps.setInt(7, c.getIdCliente());
            ps.executeUpdate();
        }
    }

    public void eliminar(int idCliente) throws SQLException {
        String sql = "DELETE FROM clientes WHERE id_cliente=?";
        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, idCliente);
            ps.executeUpdate();
        }
    }

    public List<Clientes> listarTodos() throws SQLException {
        List<Clientes> lista = new ArrayList<>();
        String sql = "SELECT * FROM clientes";
        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapear(rs));
            }
        }
        return lista;
    }

    public List<Clientes> buscarPorNombre(String texto) throws SQLException {
        List<Clientes> lista = new ArrayList<>();
        String sql = "SELECT * FROM clientes WHERE nombre LIKE ? OR apellido LIKE ?";
        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, "%" + texto + "%");
            ps.setString(2, "%" + texto + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapear(rs));
                }
            }
        }
        return lista;
    }

    private Clientes mapear(ResultSet rs) throws SQLException {
        Clientes c = new Clientes();
        c.setIdCliente(rs.getInt("id_cliente"));
        c.setNombre(rs.getString("nombre"));
        c.setApellido(rs.getString("apellido"));
        c.setEmail(rs.getString("email"));
        c.setTelefono(rs.getString("telefono"));
        c.setDireccion(rs.getString("direccion"));
        c.setFechaRegistro(rs.getDate("fecha_registro"));
        return c;
    }
    
}
