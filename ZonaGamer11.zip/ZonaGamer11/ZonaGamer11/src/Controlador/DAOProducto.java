
package Controlador;

import Conex.coneccion;
import Entidades.Producto;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;




public class DAOProducto {
    
    private static final String UPDATE_SQL = "UPDATE producto SET nombre= ?, precio = ?, precio = ?, precio = ?, id_proveedor = ?, status = ? WHERE id = ?";
    
            public ArrayList<Producto> listar() throws SQLException {
            ArrayList<Producto> lista = new ArrayList<>();
            String sql = "SELECT id_producto, nombre, descripcion, categoria, precio, id_proveedor, status FROM productos";

            try (Connection cn = coneccion.getConnection();
                 PreparedStatement ps = cn.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    Producto p = new Producto();
                    p.setIdProducto(rs.getInt("id_producto"));
                    p.setNombre(rs.getString("nombre"));
                    p.setDescripcion(rs.getString("descripcion"));
                    p.setCategoria(rs.getString("categoria"));
                    p.setPrecio(rs.getDouble("precio"));
                    p.setIdProveedor(rs.getInt("id_proveedor"));
                    p.setStatus(rs.getInt("status"));
                    lista.add(p);
                }
            }
            return lista;
        }
    
    public void insertar(Producto p) throws SQLException {
        String sql = "INSERT INTO productos(nombre, descripcion, categoria, precio,id_proveedor) "
                   + "VALUES(?,?,?,?,?)";
        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setString(1, p.getNombre());
            ps.setString(2, p.getDescripcion());
            ps.setString(3, p.getCategoria());
            ps.setDouble(4, p.getPrecio());
            ps.setInt(5, p.getIdProveedor());
            ps.executeUpdate();
        }
    }

    public void modificar(Producto p) throws SQLException {
        String sql = "UPDATE poductos SET nombre=?, descripcion=?, categoria=?, precio=? , id_proveedor=? "
                   + "WHERE id_proveedor=?";
        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setString(1, p.getNombre());
            ps.setString(2, p.getDescripcion());
            ps.setString(3, p.getCategoria());
            ps.setDouble(4, p.getPrecio());
            ps.setInt(5, p.getIdProveedor());
            ps.executeUpdate();
        }
    }

    public void eliminar(int idProducto) throws SQLException {
        String sql = "DELETE FROM productos WHERE id_proveedor=?";
        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setInt(1, idProducto);
            ps.executeUpdate();
        }
    }

    public Producto obtenerPorId(int idProducto) throws SQLException {
        String sql = "SELECT * FROM productos WHERE id_producto=?";
        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setInt(1, idProducto);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapear(rs);
                }
            }
        }
        return null;
    }

    public List<Producto> listarTodos() throws SQLException {
        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT * FROM productos";
        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapear(rs));
            }
        }
        return lista;
    }

    private Producto mapear(ResultSet rs) throws SQLException {
        return new Producto(
            rs.getInt("id_producto"),
            rs.getString("nombre"),
            rs.getString("descripcion"),
            rs.getString("categoria"),
            rs.getDouble("precio"),
            rs.getInt("id_proveedor"),
            rs.getInt("status")
        );
    }
    
    public void actualizar(Producto p) throws Exception {
        try (Connection conn = coneccion.getConnection();
             PreparedStatement ps = conn.prepareStatement(UPDATE_SQL)) {
            ps.setString(1, p.getNombre());
            ps.setString(2, p.getDescripcion());
            ps.setString(3, p.getCategoria());

            ps.setDouble(4, p.getPrecio());
            ps.setInt(5, p.getIdProveedor());

            ps.setInt(6, p.getStatus());
            ps.setInt(7, p.getIdProducto());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw e;
        }
    }
    
    public ArrayList<Producto> buscarPorNombre(String nombre) throws SQLException {

    ArrayList<Producto> lista = new ArrayList<>();
    String sql = "SELECT id_producto, nombre, descripcion, categoria, precio, id_proveedor, status "
               + "FROM productos WHERE nombre LIKE ?";

    try (Connection cn = coneccion.getConnection();
         PreparedStatement ps = cn.prepareStatement(sql)) {

        ps.setString(1, "%" + nombre + "%");

        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Producto p = new Producto();
                p.setIdProducto(rs.getInt("id_producto"));
                p.setNombre(rs.getString("nombre"));
                p.setDescripcion(rs.getString("descripcion"));
                p.setCategoria(rs.getString("categoria"));
                p.setPrecio(rs.getDouble("precio"));
                p.setIdProveedor(rs.getInt("id_proveedor"));
                p.setStatus(rs.getInt("status"));
                lista.add(p);
            }
        }
    }
    return lista;
}

}
