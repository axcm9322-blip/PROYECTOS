
package Controlador;
import Conex.coneccion;
import Entidades.DetalleVentas;
import Entidades.Facturas;
import Entidades.Ventas;
import java.sql.*;
import java.util.List;



public class DAOVenta {
  
    public int registrarVenta(Ventas v, List<DetalleVentas> detalles) throws SQLException {
        String sqlVenta = "INSERT INTO ventas(id_cliente, id_empleado, id_metodo_pago, total, status) "
                + "VALUES(?,?,?,?,?)";
        String sqlDetalle = "INSERT INTO detallesventa(id_venta, id_producto, cantidad, precio_unitario, status) "
                  + "VALUES(?,?,?,?,?)";
        
        

        Connection cn = null;
        PreparedStatement psVenta = null;
        PreparedStatement psDetalle = null;
        ResultSet rsKeys = null;

        try {
            cn = coneccion.getConnection();
            cn.setAutoCommit(false);

            // Insertar venta
            psVenta = cn.prepareStatement(sqlVenta, Statement.RETURN_GENERATED_KEYS);
            if (v.getIdCliente() != null) {
                psVenta.setInt(1, v.getIdCliente());
            } else {
                psVenta.setNull(1, Types.INTEGER);
            }
            psVenta.setInt(2, v.getIdEmpleado());
            psVenta.setInt(3, v.getIdMetodoPago());
            psVenta.setDouble(4, v.getTotal());
            psVenta.setInt(5, 1);
            psVenta.executeUpdate();

            rsKeys = psVenta.getGeneratedKeys();
            int idVenta;
            if (rsKeys.next()) {
                idVenta = rsKeys.getInt(1);
            } else {
                throw new SQLException("No se generó el ID de la venta");
            }

            // Insertar detalles
            psDetalle = cn.prepareStatement(sqlDetalle);
            for (DetalleVentas d : detalles) {
                psDetalle.setInt(1, idVenta);
                psDetalle.setInt(2, d.getIdProducto());
                psDetalle.setInt(3, d.getCantidad());
                psDetalle.setDouble(4, d.getPrecioUnitario());
                psDetalle.setInt(5, 0); // status activo (o 0 si tu sistema usa 0=activo)
                psDetalle.addBatch();

            }
            psDetalle.executeBatch();

            cn.commit();
            return idVenta;

        } catch (SQLException ex) {
            if (cn != null) cn.rollback();
            throw ex;
        } finally {
            if (rsKeys != null) rsKeys.close();
            if (psDetalle != null) psDetalle.close();
            if (psVenta != null) psVenta.close();
            if (cn != null) cn.setAutoCommit(true);
            if (cn != null) cn.close();
        }
    }

    public void registrarFactura(Facturas f) throws SQLException {
        String sql = "INSERT INTO facturas(id_venta, iva, total_con_iva, estado) "
                   + "VALUES(?,?,?,?)";
        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setInt(1, f.getIdVenta());
            ps.setDouble(2, f.getIva());
            ps.setDouble(3, f.getTotalConIva());
            ps.setString(4, f.getEstado());
            ps.executeUpdate();
        }
    }
    
}
