/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Conex.coneccion;
import Entidades.CitasServicio;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DAOCita {

    private static final String UPDATE_SQL =
        "UPDATE citasservicio SET id_cliente=?, id_empleado=?, id_producto=?, descripcion_problema=?, "
      + "fecha_cita=?, hora_cita=?, estado=?, costo_estimado=? WHERE id_cita=?";

    // LISTAR
    public ArrayList<CitasServicio> listar() throws SQLException {
        ArrayList<CitasServicio> lista = new ArrayList<>();
        String sql = "SELECT * FROM citasservicio";

        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapear(rs));
            }
        }
        return lista;
    }

    // INSERTAR
    public void insertar(CitasServicio c) throws SQLException {
        String sql = "INSERT INTO citasservicio(id_cliente, id_empleado, id_producto, descripcion_problema, "
                   + "fecha_cita, hora_cita, estado, costo_estimado) VALUES (?,?,?,?,?,?,?,?)";

        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setInt(1, c.getIdCliente());
            ps.setInt(2, c.getIdEmpleado());
            ps.setInt(3, c.getIdProducto());
            ps.setString(4, c.getDescripcionProblema());
            ps.setDate(5, new java.sql.Date(c.getFechaCita().getTime()));
            ps.setTime(6, c.getHoraCita());
            ps.setString(7, c.getEstado());
            ps.setDouble(8, c.getCostoEstimado());

            ps.executeUpdate();
        }
    }

    // MODIFICAR
    public void modificar(CitasServicio c) throws SQLException {
        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(UPDATE_SQL)) {

            ps.setInt(1, c.getIdCliente());
            ps.setInt(2, c.getIdEmpleado());
            ps.setInt(3, c.getIdProducto());
            ps.setString(4, c.getDescripcionProblema());
            ps.setDate(5, new java.sql.Date(c.getFechaCita().getTime()));
            ps.setTime(6, c.getHoraCita());
            ps.setString(7, c.getEstado());
            ps.setDouble(8, c.getCostoEstimado());
            ps.setInt(9, c.getIdCita());

            ps.executeUpdate();
        }
    }

    // ELIMINAR
    public void eliminar(int idCita) throws SQLException {
        String sql = "DELETE FROM citasservicio WHERE id_cita=?";

        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setInt(1, idCita);
            ps.executeUpdate();
        }
    }

    // OBTENER POR ID
    public CitasServicio obtenerPorId(int idCita) throws SQLException {
        String sql = "SELECT * FROM citasservicio WHERE id_cita=?";

        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setInt(1, idCita);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapear(rs);
                }
            }
        }
        return null;
    }
    
    //Buscar por nombre //
    public ArrayList<CitasServicio> buscarPorNombreCliente(String nombre) throws SQLException {
    ArrayList<CitasServicio> lista = new ArrayList<>();
    String sql = "SELECT c.* FROM citasservicio c "
               + "INNER JOIN clientes cl ON c.id_cliente = cl.id_cliente "
               + "WHERE cl.nombre LIKE ?";

    try (Connection cn = coneccion.getConnection();
         PreparedStatement ps = cn.prepareStatement(sql)) {

        ps.setString(1, "%" + nombre + "%");

        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapear(rs));
            }
        }
    }
    return lista;
}


    // MAPEO
    private CitasServicio mapear(ResultSet rs) throws SQLException {
        CitasServicio c = new CitasServicio();

        c.setIdCita(rs.getInt("id_cita"));
        c.setIdCliente(rs.getInt("id_cliente"));
        c.setIdEmpleado(rs.getInt("id_empleado"));
        c.setIdProducto(rs.getInt("id_producto"));
        c.setDescripcionProblema(rs.getString("descripcion_problema"));
        c.setFechaCita(rs.getDate("fecha_cita"));
        c.setHoraCita(rs.getTime("hora_cita"));
        c.setEstado(rs.getString("estado"));
        c.setCostoEstimado(rs.getDouble("costo_estimado"));

        return c;
    }
}


