
package Controlador;
import Conex.coneccion;
import java.sql.*;


public class DAOFactura {
    
    public void insertarFactura(int idVenta, double iva, double total) throws SQLException {

        String sql = "INSERT INTO facturas(id_venta, fecha_emision, iva, total_con_iva, estado, status) "
                   + "VALUES(?, NOW(), ?, ?, 'Emitida', 0)";

        try (Connection cn = coneccion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setInt(1, idVenta);
            ps.setDouble(2, iva);
            ps.setDouble(3, total);

            ps.executeUpdate();
        }
    }
    
}





    

