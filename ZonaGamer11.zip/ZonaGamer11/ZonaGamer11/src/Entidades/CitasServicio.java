
package Entidades;

import java.util.Date;


public class CitasServicio {
     private int idCita;
    private int idCliente;
    private int idEmpleado;
    private int idProducto;
    private String descripcionProblema;
    private Date fechaCita;
    private java.sql.Time horaCita;
    private String estado;      // Pendiente, En Progreso, etc.
    private double costoEstimado;
    private int status;

    public int getStatus() { return status; }
    public void setStatus(int status) { this.status = status; }

    public int getIdCita() { return idCita; }
    public void setIdCita(int idCita) { this.idCita = idCita; }

    public int getIdCliente() { return idCliente; }
    public void setIdCliente(int idCliente) { this.idCliente = idCliente; }

    public int getIdEmpleado() { return idEmpleado; }
    public void setIdEmpleado(int idEmpleado) { this.idEmpleado = idEmpleado; }

    public int getIdProducto() { return idProducto; }
    public void setIdProducto(int idProducto) { this.idProducto = idProducto; }

    public String getDescripcionProblema() { return descripcionProblema; }
    public void setDescripcionProblema(String descripcionProblema) { this.descripcionProblema = descripcionProblema; }

    public Date getFechaCita() { return fechaCita; }
    public void setFechaCita(Date fechaCita) { this.fechaCita = fechaCita; }

    public java.sql.Time getHoraCita() { return horaCita; }
    public void setHoraCita(java.sql.Time horaCita) { this.horaCita = horaCita; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public double getCostoEstimado() { return costoEstimado; }
    public void setCostoEstimado(double costoEstimado) { this.costoEstimado = costoEstimado; }
}
