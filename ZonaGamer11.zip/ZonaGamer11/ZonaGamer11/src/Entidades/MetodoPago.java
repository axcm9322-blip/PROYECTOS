
package Entidades;

public class MetodoPago {
    
    private int idMetodoPago;
    private String metodoPago;
    
    public int getIdMetodoPago() { return idMetodoPago; }
    public void setIdMetodoPago(int idMetodoPago) { this.idMetodoPago = idMetodoPago; }

    public String getMetodoPago() { return metodoPago; }
    public void setMetodoPago(String metodoPago) { this.metodoPago = metodoPago; }

    @Override
    public String toString() {
        return metodoPago;
    }
    
}
