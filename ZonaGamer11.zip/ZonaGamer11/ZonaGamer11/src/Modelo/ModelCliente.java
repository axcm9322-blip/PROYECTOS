
package Modelo;

import Entidades.Clientes;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

public class ModelCliente extends AbstractTableModel {
    

    private List<Clientes> lista = new ArrayList<>();


    
    private final String[] columnas = {"ID", "Nombre", "Apellido", "Email", "Teléfono"};

    public void setLista(List<Clientes> lista) {
        this.lista = lista;
        fireTableDataChanged();
    }

    public Clientes getClienteAt(int fila) {
        return lista.get(fila);
    }

    @Override
    public int getRowCount() {
        return lista.size();
    }

    @Override
    public int getColumnCount() {
        return columnas.length;
    }

    @Override
    public String getColumnName(int column) {
        return columnas[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Clientes c = lista.get(rowIndex);
        switch (columnIndex) {
            case 0: return c.getIdCliente();
            case 1: return c.getNombre();
            case 2: return c.getApellido();
            case 3: return c.getEmail();
            case 4: return c.getTelefono();
            default: return "";
        }
    }
    
}
