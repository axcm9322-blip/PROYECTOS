
package Modelo;
import Entidades.DetalleVentas;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

public class ModelDetalleVenta extends AbstractTableModel{
    
    private List<DetalleVentas> lista = new ArrayList<>();
    private final String[] columnas = {"Producto", "Precio", "Cantidad", "Subtotal"};

    public void setLista(List<DetalleVentas> lista) {
        this.lista = lista;
        fireTableDataChanged();
    }

    public List<DetalleVentas> getLista() {
        return lista;
    }

    public DetalleVentas getDetalleAt(int fila) {
        return lista.get(fila);
    }

    public void agregar(DetalleVentas d) {
        lista.add(d);
        fireTableDataChanged();
    }

    public void eliminar(int fila) {
        lista.remove(fila);
        fireTableDataChanged();
    }

    @Override
    public int getRowCount() {
        return lista.size();
    }

    @Override
    public int getColumnCount() {
        return columnas.length;
    }

    @Override
    public String getColumnName(int column) {
        return columnas[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        DetalleVentas d = lista.get(rowIndex);
        switch (columnIndex) {
            case 0: return d.getIdProducto();   // puedes cambiarlo por nombre si lo traes junto
            case 1: return d.getPrecioUnitario();
            case 2: return d.getCantidad();
            case 3: return d.getSubtotal();
            default: return "";
        }
    }
    
    
    
}
