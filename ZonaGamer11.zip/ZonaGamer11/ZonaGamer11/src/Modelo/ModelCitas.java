/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Entidades.CitasServicio;
import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;

public class ModelCitas extends AbstractTableModel {

    private ArrayList<CitasServicio> select = null;

    // Establecer la lista de citas y refrescar la tabla
    public void setSelectCitas(ArrayList<CitasServicio> selectCitas){
        this.select = selectCitas;
        fireTableDataChanged();
    }

    // Obtener la lista de citas
    public ArrayList<CitasServicio> getSelectCitas(){
        return select;
    }

    @Override
    public int getRowCount() {
        if(this.select != null){
            return this.select.size();
        }
        return 0;
    }

    @Override
    public int getColumnCount() {
        return 9; // idCita, idCliente, idEmpleado, idProducto, descripcion, fecha, hora, estado, costo
    }

    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0: return "ID Cita";
            case 1: return "ID Cliente";
            case 2: return "ID Empleado";
            case 3: return "ID Producto";
            case 4: return "Descripcion";
            case 5: return "Fecha";
            case 6: return "Hora";
            case 7: return "Estado";
            case 8: return "Costo Estimado";
            default: throw new AssertionError("Columna no válida: " + column);
        }
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        if(this.select == null) return null;

        CitasServicio cita = this.select.get(rowIndex);

        switch(columnIndex){
            case 0: return cita.getIdCita();
            case 1: return cita.getIdCliente();
            case 2: return cita.getIdEmpleado();
            case 3: return cita.getIdProducto();
            case 4: return cita.getDescripcionProblema();
            case 5: return cita.getFechaCita();
            case 6: return cita.getHoraCita();
            case 7: return cita.getEstado();
            case 8: return cita.getCostoEstimado();
            default: return null;
        }
    }

    // Obtener la cita en un índice específico
    public CitasServicio getCitaAt(int index) {
        if(this.select != null && index >= 0 && index < select.size()){
            return select.get(index);
        }
        return null;
    }
}

