
package Modelo;


import Entidades.Proveedores;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;
public class ModelProveedor extends AbstractTableModel {
    
    private List<Proveedores> lista = new ArrayList<>();
    private final String[] columnas = {"ID", "Nombre", "Contacto", "Teléfono", "Email"};

    public void setLista(List<Proveedores> lista) {
        this.lista = lista;
        fireTableDataChanged();
    }

    public Proveedores getProveedorAt(int fila) {
        return lista.get(fila);
    }

    @Override
    public int getRowCount() {
        return lista.size();
    }

    @Override
    public int getColumnCount() {
        return columnas.length;
    }

    @Override
    public String getColumnName(int column) {
        return columnas[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Proveedores p = lista.get(rowIndex);
        switch (columnIndex) {
            case 0: return p.getIdProveedor();
            case 1: return p.getNombre();
            case 2: return p.getContacto();
            case 3: return p.getTelefono();
            case 4: return p.getEmail();
            default: return "";
        }
    }
    
    
}
