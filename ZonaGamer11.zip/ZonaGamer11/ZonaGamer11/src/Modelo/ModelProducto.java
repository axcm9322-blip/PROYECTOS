
package Modelo;

import Entidades.Producto;
import java.util.ArrayList;
import java.util.ArrayList;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;
import java.math.BigDecimal;

public class ModelProducto extends AbstractTableModel{
     private ArrayList<Producto> select = null;
     
     public void setSelectProducto(ArrayList selectProducto){
         this.select = selectProducto;
         fireTableDataChanged();
     }
     
     public ArrayList getSelectProducto(){
         return select;
     }
     

    @Override
    public int getRowCount() {
                      int cantFlias = 0;
      if(this.select != null){
           cantFlias = this.select.size();
      }  
      return cantFlias; 
    }

    @Override
    public int getColumnCount() {
        return 7;
    }

    @Override
    public String getColumnName(int column) {
        String nombreCol = "";
        
        switch (column) {
            case 0 : nombreCol = "id"; break;           
            case 1 : nombreCol = "Nombre"; break;
            case 2 : nombreCol = "Descripcion"; break;
            case 3 : nombreCol = "Categoria"; break;
            case 4 : nombreCol = "precio "; break;
            case 5 : nombreCol = "ID proveedor"; break;
            case 6 : nombreCol = "Activo"; break;

            
            default:
                throw new AssertionError();
        }  
        return nombreCol;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
              Object celda = "";
      Producto objC = null;
      
      if(this.select != null){
          objC =  this.select.get(rowIndex);
        switch (columnIndex) {
            case 0 : celda = objC.getIdProducto(); break;           
            case 1 : celda = objC.getNombre(); break;
            case 2 : celda = objC.getDescripcion(); break;
            case 3 : celda = objC.getCategoria(); break;
            case 4 : celda = objC.getPrecio(); break;
            case 5 : celda = objC.getIdProveedor(); break;            
            case 6 : celda = objC.getStatus(); break;
           
        } 
      }
      return celda;
    }

   
        public Producto getProductoAt(int index) {
        Producto obj = null;
        if(this.select != null) obj = (Producto)select.get(index);
        return obj;
    }

        
    
public void agregarProductoCarrito(JTable tablaCarrito, Producto p) {
    DefaultTableModel m;

    if (tablaCarrito.getModel() instanceof DefaultTableModel) {
        m = (DefaultTableModel) tablaCarrito.getModel();
    } else {
        m = new DefaultTableModel();
        tablaCarrito.setModel(m);
    }

    // Si la tabla aún no tiene columnas, las creamos
    if (m.getColumnCount() == 0) {
        m.setColumnIdentifiers(new Object[]{"ID", "Nombre", "Precio"});
    }

    m.addRow(new Object[]{
        p.getIdProducto(),
        p.getNombre(),
        p.getPrecio()
    });
    }

}
