/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Entidades.Compra;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author YEINER
 */
public class ModelCompras extends AbstractTableModel{
    
   
    private ArrayList<Compra> comp = new ArrayList<>();

    private final String[] columnas = {
        "ID Pedido",
        "ID Proveedor",
        "Fecha Pedido",
        "Fecha Entrega",
        "Estado",
        "Total"
    };

    public void setSelectCompra(ArrayList<Compra> lista) {
        this.comp = lista;
        fireTableDataChanged();
    }

    @Override
    public int getRowCount() {
        return comp.size();
    }

    @Override
    public int getColumnCount() {
        return columnas.length;
    }

    @Override
    public String getColumnName(int column) {
        return columnas[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Compra c = comp.get(rowIndex);

        switch (columnIndex) {
            case 0: return c.getIdPedido();
            case 1: return c.getIdProveedor();
            case 2: return c.getFechaPedido();
            case 3: return c.getFechaEntregaEstimada();
            case 4: return c.getEstado();
            case 5: return c.getTotal();
            default: return null;
        }
    }

    public Compra getCompraAt(int index) {
        return comp.get(index);
    }
}
